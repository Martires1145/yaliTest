create
    definer = root@localhost procedure insert_rdno(IN min int, IN max int)
BEGIN
    DECLARE i int default 0;
    DECLARE a int default 0;
    set autocommit = 0;
    repeat
        set a = FLOOR( min + RAND() * ( max+1-min ) );
        insert into dt(rand_num,rand_value) VALUES (a,(min+i));
        set i = i+1;
    until min+i-1 = max
        end repeat;
    commit;
END;

