create definer = root@localhost trigger article_delete
    before delete
    on articles
    for each row
BEGIN
        DELETE FROM content
        WHERE content.id = OLD.content_id;
        DELETE FROM categories
        WHERE article_id = OLD.id;
    end;

