create
    definer = root@localhost procedure CRpcrScore()
BEGIN
    Select Student.Sno as 学号,Student.Sname as 姓名 ,Course.Cno as 课程号 ,Course.Cname as 课程名,sc.Grade as 成绩
    from sc, Student ,Course
    where sc.Sno =Student.Sno and sc.Cno=Course.Cno;
END;

