create
    definer = root@localhost procedure CRprcDepartCnt(IN dept char(20))
BEGIN
    Select sum(Cnt) `cnt` from  crvwdepartmajorcount
    WHERE Sdept = dept;
end;

