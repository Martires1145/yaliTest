create
    definer = root@localhost procedure CRprcFindByNo(IN id char(10))
BEGIN
    Select * from  crvwscore
    WHERE 学号 LIKE CONCAT('%', id, '%');
end;

