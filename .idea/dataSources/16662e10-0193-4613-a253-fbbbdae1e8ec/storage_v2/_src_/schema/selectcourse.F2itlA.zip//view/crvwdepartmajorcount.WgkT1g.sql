create definer = root@localhost view crvwdepartmajorcount as
select `selectcourse`.`student`.`Sdept`               AS `Sdept`,
       `selectcourse`.`student`.`Smajor`              AS `Smajor`,
       count(distinct `selectcourse`.`student`.`Sno`) AS `Cnt`
from `selectcourse`.`student`
group by `selectcourse`.`student`.`Sdept`, `selectcourse`.`student`.`Smajor`;

