create definer = root@localhost view crvwscore as
select `selectcourse`.`student`.`Sno`   AS `学号`,
       `selectcourse`.`student`.`Sname` AS `姓名`,
       `selectcourse`.`course`.`Cno`    AS `课程号`,
       `selectcourse`.`course`.`Cname`  AS `课程名`,
       `selectcourse`.`sc`.`Grade`      AS `成绩`
from `selectcourse`.`student`
         join `selectcourse`.`course`
         join `selectcourse`.`sc`
where ((`selectcourse`.`student`.`Sno` = `selectcourse`.`sc`.`Sno`) and
       (`selectcourse`.`course`.`Cno` = `selectcourse`.`sc`.`Cno`));

