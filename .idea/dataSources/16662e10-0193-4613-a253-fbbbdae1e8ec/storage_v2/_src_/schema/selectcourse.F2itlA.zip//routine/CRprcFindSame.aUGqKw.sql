create
    definer = root@localhost procedure CRprcFindSame(IN name char(20))
BEGIN
    Select * from  Student
    WHERE (Smajor, Sdept) = (SELECT Smajor, Sdept FROM student WHERE Sname = name);
end;

