create definer = root@localhost view vwip as
select `mydb`.`iptable`.`iId`       AS `自增编号`,
       `mydb`.`iptable`.`vHostName` AS `主机名`,
       `mydb`.`iptable`.`vIp`       AS `IP地址`,
       `mydb`.`iptable`.`vRoomNo`   AS `房间号`
from `mydb`.`iptable`;

grant select on table vwip to iot2018@localhost;

