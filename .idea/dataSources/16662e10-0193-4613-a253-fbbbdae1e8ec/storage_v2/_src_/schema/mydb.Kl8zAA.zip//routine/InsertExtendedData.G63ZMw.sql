create
    definer = root@localhost procedure InsertExtendedData()
BEGIN
    DECLARE counter INT DEFAULT 0;

    WHILE counter < 10 DO
            INSERT INTO IpTable (vHostName, vIp, vRoomNo)
            SELECT
                CONCAT('B413-', counter + 20),
                CONCAT('172.23.254.', 200 + counter),
                'SWPU明理楼B-413'
            FROM dual
            WHERE NOT EXISTS (
                    SELECT 1
                    FROM IpTable
                    WHERE vIp = CONCAT('172.23.254.', 200 + counter)
                );

            SET counter = counter + 1;
        END WHILE;
END;

