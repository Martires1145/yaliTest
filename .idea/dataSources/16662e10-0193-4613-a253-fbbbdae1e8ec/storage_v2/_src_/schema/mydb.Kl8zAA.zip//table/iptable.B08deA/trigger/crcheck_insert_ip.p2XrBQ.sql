create definer = root@localhost trigger CRcheck_insert_ip
    before insert
    on iptable
    for each row
BEGIN
    DECLARE last_octet VARCHAR(3);
    SET last_octet = SUBSTRING(NEW.vIp, -3);
    IF last_octet = '.255' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '不能插入以.255结尾的IP地址';
    END IF;
END;

