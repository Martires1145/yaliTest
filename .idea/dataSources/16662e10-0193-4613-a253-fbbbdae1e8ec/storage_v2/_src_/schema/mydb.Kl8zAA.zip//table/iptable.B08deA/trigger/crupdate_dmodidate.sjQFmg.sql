create definer = root@localhost trigger CRupdate_dModiDate
    before update
    on iptable
    for each row
BEGIN
    SET NEW.dModiDate = CURRENT_TIMESTAMP;
END;

