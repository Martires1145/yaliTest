create definer = root@localhost trigger CRprevent_delete_low_id
    before delete
    on iptable
    for each row
BEGIN
    IF OLD.iID < 9 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = '不能删除iID小于9的数据';
    END IF;
END;

